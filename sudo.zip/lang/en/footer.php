<?php

return [
    'company' => 'Company',
    'about' => 'About',
    'publications' => 'Publications',
    'reviews' => 'Testimonials',
    'services' => 'Services',
    'projects' => 'Projects',
    'instruments' => 'Tools',
    'career' => 'Careers',
    'contacts' => 'Contacts',
    'information' => 'Information',
    'policy' => 'Privacy Policy',
    'copyright' => '© :year, Sudo LLC. All rights reserved',
];
