<footer class="footer ps-40">
    <div class="footer__wrap">
        <div class="footer__block">
            <a class="logo footer__logo" href="/">
                <img src="<?php echo e(Vite::asset('resources/images/svg/logo.svg'), false); ?>" alt="лого">
            </a>

            <ul class="footer__nav">
                <li><a href="<?php echo e(route('about'), false); ?>"><?php echo e(__('footer.company'), false); ?></a></li>
                <li><a href="<?php echo e(route('services'), false); ?>"><?php echo e(__('footer.services'), false); ?></a></li>
                <li><a href="<?php echo e(route('projects'), false); ?>"><?php echo e(__('footer.projects'), false); ?></a></li>
            </ul>

            <ul class="footer__nav">
                <li><a href="<?php echo e(route('calculations'), false); ?>"><?php echo e(__('footer.instruments'), false); ?></a></li>
                <li><a href="<?php echo e(route('career'), false); ?>"><?php echo e(__('footer.career'), false); ?></a></li>
                <li><a href="<?php echo e(route('contacts'), false); ?>"><?php echo e(__('footer.contacts'), false); ?></a></li>
            </ul>

            <ul class="footer__info">
                <li><?php echo e(__('footer.information'), false); ?></li>
                <li><a href="<?php echo e(route('policy'), false); ?>"><?php echo e(__('footer.policy'), false); ?></a></li>
                <!-- <li><a href="#">Политика использования Cookies</a></li> -->
            </ul>

            <ul class="footer__contact">
                <li><a href="mailto:<?php echo e(contacts()->email, false); ?>"><?php echo e(contacts()->email, false); ?></a></li>
            </ul>
        </div>
        <p class="footer__copyright"><?php echo e(__('footer.copyright', ['year' => now()->format('Y')]), false); ?></p>
    </div>

</footer>
<?php /**PATH /home/aner/web_dev/sudo/resources/views/layouts/partials/footer.blade.php ENDPATH**/ ?>