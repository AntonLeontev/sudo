<h1 <?php echo e($attributes->merge(['class' => 'truncate text-md font-medium']), false); ?>>
    <?php echo e($slot, false); ?>

</h1>
<?php /**PATH /home/aner/web_dev/sudo/vendor/moonshine/moonshine/resources/views/components/title.blade.php ENDPATH**/ ?>