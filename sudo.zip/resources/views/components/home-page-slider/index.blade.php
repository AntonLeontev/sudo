<div class="card-box swiper-box">
    <div class="swiper-wrapper">
        {{ $slot }}
    </div>

    <!-- If we need navigation buttons -->
    <div class="swiper-button-prev"></div>
    <div class="swiper-button-next"></div>
</div>
