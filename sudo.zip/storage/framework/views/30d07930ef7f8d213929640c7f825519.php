<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
	'slide',
	'position',
	'total',
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
	'slide',
	'position',
	'total',
]); ?>
<?php foreach (array_filter(([
	'slide',
	'position',
	'total',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<?php
	$text = 'text_' . app()->getLocale();
	$button = 'button_text_' . app()->getLocale();
?>

<div class="swiper-slide">
    <div class="index-block" style="background-image: url('/storage/<?php echo e($slide->image, false); ?>')">
        <div class="index-block__wrap">
            <span class="elem-a2 wow fadeInUp swiper-slide__number" data-wow-duration=".2s" style="color: <?php echo e($slide->text_color, false); ?>">
				<?php echo e(str($position)->padLeft(2, '0'), false); ?> - <?php echo e(str($total)->padLeft(2, '0'), false); ?>

			</span>
            <div class="wow fadeInUp swiper-slide__text" data-wow-duration=".5s" style="color: <?php echo e($slide->text_color, false); ?>">
				<?php echo $slide->{$text}; ?>

			</div>

			<?php if($slide->has_request_button): ?>
				<div class="index-block__btn-box elem-a3 wow zoomIn">
					<button class="index-block__btn request-button"><?php echo e(__('home.slide-button'), false); ?></button>
				</div>
			<?php else: ?>
				<div class="index-block__btn-box elem-a3 wow zoomIn">
					<a href="<?php echo e($slide->button_link, false); ?>" class="index-block__btn home-page-slide__link" target="_blank"><?php echo e($slide->{$button}, false); ?></a>
				</div>
			<?php endif; ?>
        </div>
    </div>
</div>
<?php /**PATH /home/aner/web_dev/sudo/resources/views/components/home-page-slider/slide.blade.php ENDPATH**/ ?>