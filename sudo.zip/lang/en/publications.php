<?php

return [
    'title' => 'Publications',
    'h1' => 'Publications',
    'publication' => [
        'button' => 'Read more',
    ],
];
