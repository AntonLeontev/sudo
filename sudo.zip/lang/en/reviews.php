<?php

return [
    'title' => 'Testimonials',
    'h1' => 'Testimonials',
    '1' => 'ФГУП ВНИИ им. Д.И. Менделеева',
];
