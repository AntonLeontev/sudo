<?php

return [
    'company' => 'Компания',
    'about' => 'О Нас',
    'publications' => 'Публикации',
    'reviews' => 'Отзывы',
    'services' => 'Услуги',
    'projects' => 'Проекты',
    'instruments' => 'Инструменты',
    'career' => 'Карьера',
    'contacts' => 'Контакты',
    'search' => 'Поиск...',
    'search-placeholder' => 'Введите названия',
];
