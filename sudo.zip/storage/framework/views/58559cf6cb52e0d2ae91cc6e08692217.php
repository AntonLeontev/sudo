<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"
     class="fill-current w-<?php echo e($size ?? 5, false); ?> h-<?php echo e($size ?? 5, false); ?> <?php echo e($class ?? '', false); ?> <?php echo e(isset($color) ? "text-$color" : '', false); ?>">
  <path d="M5.566 4.657A4.505 4.505 0 016.75 4.5h10.5c.41 0 .806.055 1.183.157A3 3 0 0015.75 3h-7.5a3 3 0 00-2.684 1.657zM2.25 12a3 3 0 013-3h13.5a3 3 0 013 3v6a3 3 0 01-3 3H5.25a3 3 0 01-3-3v-6zM5.25 7.5c-.41 0-.806.055-1.184.157A3 3 0 016.75 6h10.5a3 3 0 012.683 1.657A4.505 4.505 0 0018.75 7.5H5.25z"/>
</svg>
<?php /**PATH /home/aner/web_dev/sudo/vendor/moonshine/moonshine/resources/views/ui/icons/heroicons/rectangle-stack.blade.php ENDPATH**/ ?>