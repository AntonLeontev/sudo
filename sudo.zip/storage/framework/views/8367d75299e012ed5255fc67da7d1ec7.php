<header class="header">
    <div class="header__wrap">

        <button class="menu-btn header__menu-btn">
            <span></span>
            <span></span>
        </button>


        <a class="logo header__logo" href="<?php echo e(route('home'), false); ?>">
            <img src="<?php echo e(Vite::asset('resources/images/svg/logo.svg'), false); ?>" alt="лого">
        </a>

        <nav class="menu header__menu">
            <ul class="menu__list">
                <li class="menu__item">
                    <a class="menu__link menu__link-list" href="#"><?php echo e(__('header.company'), false); ?><i class="icon-arrow-bootom"></i></a>
                    <ul class="menu__list-2">
                        <li>
                            <a class="menu__link" href="<?php echo e(route('about'), false); ?>"><?php echo e(__('header.about'), false); ?></a>
                        </li>
                        <li>
                            <a class="menu__link" href="<?php echo e(route('publications'), false); ?>"><?php echo e(__('header.publications'), false); ?></a>
                        </li>
                        <li>
                            <a class="menu__link" href="<?php echo e(route('reviews'), false); ?>"><?php echo e(__('header.reviews'), false); ?></a>
                        </li>
                    </ul>
                </li>
                <li class="menu__item"><a class="menu__link" href="<?php echo e(route('services'), false); ?>"><?php echo e(__('header.services'), false); ?></a></li>
                <li class="menu__item"><a class="menu__link" href="<?php echo e(route('projects'), false); ?>"><?php echo e(__('header.projects'), false); ?></a></li>
                <li class="menu__item"><a class="menu__link" href="<?php echo e(route('calculations'), false); ?>"><?php echo e(__('header.instruments'), false); ?></a></li>
                <li class="menu__item"><a class="menu__link" href="<?php echo e(route('career'), false); ?>"><?php echo e(__('header.career'), false); ?></a></li>
                <li class="menu__item"><a class="menu__link" href="<?php echo e(route('contacts'), false); ?>"><?php echo e(__('header.contacts'), false); ?></a></li>
            </ul>
            <ul class="menu__contact">
                <li><a href="mailto:<?php echo e(contacts()->email, false); ?>"><?php echo e(contacts()->email, false); ?></a></li>
            </ul>
        </nav>

        <button class="header__search-btn search-btn">
            <i class="icon-search"></i>
        </button>
        <div class="header__lang lang">
            
			<?php
				if (app()->getLocale() === 'en') {
					$lang = 'ru';
				} else {
					$lang = 'en';
				}
			?>
			<a href="<?php echo e(route('language', $lang), false); ?>">
				<?php echo e(strtoupper($lang), false); ?>

			</a>
            
        </div>

        <div class="header__search search">
            <button class="search__close">
                <i class="icon-close"></i>
            </button>
            <p class="search__text"><?php echo e(__('header.search'), false); ?></p>
            <label class="search__label">
                <input class="search__input" type="text" placeholder="<?php echo e(__('header.search-placeholder'), false); ?>">
                <button class="search__btn">
                    <i class="icon-enter"></i>
                </button>
            </label>
        </div>
    </div>
</header>
<?php /**PATH /home/aner/web_dev/sudo/resources/views/layouts/partials/header.blade.php ENDPATH**/ ?>