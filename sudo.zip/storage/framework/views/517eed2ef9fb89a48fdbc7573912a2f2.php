<div class="mb-4">
    <?php echo e($element->label(), false); ?>

</div>
<?php /**PATH /home/aner/web_dev/sudo/vendor/moonshine/moonshine/resources/views/decorations/heading.blade.php ENDPATH**/ ?>