<div class="card-box swiper-box">
    <div class="swiper-wrapper">
        <?php echo e($slot, false); ?>

    </div>

    <!-- If we need navigation buttons -->
    <div class="swiper-button-prev"></div>
    <div class="swiper-button-next"></div>
</div>
<?php /**PATH /home/aner/web_dev/sudo/resources/views/components/home-page-slider/index.blade.php ENDPATH**/ ?>