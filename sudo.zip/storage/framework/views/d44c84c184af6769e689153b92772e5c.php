<?php
	$name = 'name_' . app()->getLocale();
	$surname = 'surname_' . app()->getLocale();
	$position = 'position_' . app()->getLocale();
	$address = 'address_' . app()->getLocale();
?>
BEGIN:VCARD
VERSION:3.0
FN;CHARSET=UTF-8:<?php echo e($employee->{$name}, false); ?> <?php echo e($employee->{$surname}, false); ?>

N;CHARSET=UTF-8:<?php echo e($employee->{$surname}, false); ?>;<?php echo e($employee->{$name}, false); ?>;;;
<?php if($employee->email): ?>
EMAIL;CHARSET=UTF-8;type=HOME,INTERNET:<?php echo e($employee->email, false); ?>

<?php endif; ?>
<?php if($employee->phone): ?>
TEL;TYPE=CELL:+<?php echo e(preg_replace('~ |-~', '', $employee->phone), false); ?>

<?php endif; ?>
<?php if($employee->{$position}): ?>
TITLE;CHARSET=UTF-8:<?php echo e($employee->{$position}, false); ?>

<?php endif; ?>
<?php if(contacts()->company_name): ?>
ORG;CHARSET=UTF-8:<?php echo e(contacts()->company_name, false); ?>

<?php endif; ?>
<?php if(contacts()->website): ?>
URL;CHARSET=UTF-8:<?php echo e(contacts()->website, false); ?>

<?php endif; ?>
REV:<?php echo e(now()->toISOString(), false); ?>

END:VCARD
<?php /**PATH /home/aner/web_dev/sudo/resources/views/files/vcard.blade.php ENDPATH**/ ?>