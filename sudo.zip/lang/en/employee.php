<?php

return [
    'Add to contacts' => 'Add to contacts',
    'Contact' => 'Contact',
    'Company' => 'Company',
    'Socials' => 'Socials',
    'Mobile phone' => 'Mobile phone',
    'Email' => 'Email',
    'Personal website' => 'Personal website',
    'Location' => 'Location',
    'Profession' => 'Profession',
    'Phone' => 'Phone',
    'to the website' => 'To the website',
];
