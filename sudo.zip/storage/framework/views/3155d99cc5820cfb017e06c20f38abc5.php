<?php echo $__env->make('moonshine::fields.input', [
    'element' => $element,
    'item' => $resource->getModel(),
    'resource' => $resource,
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /home/aner/web_dev/sudo/vendor/moonshine/moonshine/resources/views/filters/text.blade.php ENDPATH**/ ?>