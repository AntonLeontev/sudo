Имя: {{ request()->name }}
Телефон: {{ request()->phone }}
Email: {{ request()->email }}
Описание: {{ request()->description }}
