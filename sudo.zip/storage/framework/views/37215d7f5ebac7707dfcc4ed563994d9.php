<div <?php echo e($attributes->merge(['class' => 'grid grid-cols-12 gap-6']), false); ?>>
    <?php echo e($slot, false); ?>

</div>
<?php /**PATH /home/aner/web_dev/sudo/vendor/moonshine/moonshine/resources/views/components/grid.blade.php ENDPATH**/ ?>