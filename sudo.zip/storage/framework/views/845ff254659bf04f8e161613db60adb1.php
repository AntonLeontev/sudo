<?php echo $__env->make('moonshine::fields.select', [
    'element' => $element,
    'resource' => $resource,
    'item' => $resource->getModel()
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /home/aner/web_dev/sudo/vendor/moonshine/moonshine/resources/views/filters/select.blade.php ENDPATH**/ ?>