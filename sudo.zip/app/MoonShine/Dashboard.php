<?php

namespace App\MoonShine;

use MoonShine\Dashboard\DashboardScreen;

class Dashboard extends DashboardScreen
{
    public function blocks(): array
    {
        return [];
    }
}
