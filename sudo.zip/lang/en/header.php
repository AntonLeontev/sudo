<?php

return [
    'company' => 'Company',
    'about' => 'About us',
    'publications' => 'Publications',
    'reviews' => 'Testimonials',
    'services' => 'Services',
    'projects' => 'Projects',
    'instruments' => 'Tools',
    'career' => 'Careers',
    'contacts' => 'Contacts',
    'search' => 'Search...',
    'search-placeholder' => 'Enter titles',
];
