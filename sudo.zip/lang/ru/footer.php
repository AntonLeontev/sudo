<?php

return [
    'company' => 'Компания',
    'about' => 'О Нас',
    'publications' => 'Публикации',
    'reviews' => 'Отзывы',
    'services' => 'Услуги',
    'projects' => 'Проекты',
    'instruments' => 'Инструменты',
    'career' => 'Карьера',
    'contacts' => 'Контакты',
    'information' => 'Информация',
    'policy' => 'Политика конфиденциальности',
    'copyright' => '© :year, ООО Судо. Все права сайта защищены',
];
