<?php $__env->startSection('title', __('home.title')); ?>

<?php $__env->startSection('body-class', 'main-blue'); ?>

<?php $__env->startSection('content'); ?>
    <main>

        <section class="hero card-box card-box--active">
            <div class="hero__wrap ps-40">

                <h1 class="mob"><?php echo e(__('home.h1.mob'), false); ?></h1>

                <h1 class="tab dest">
                    <span class="hero__title"><?php echo e(__('home.h1.1'), false); ?></span>
					<br>
                    <span class="hero__title"><?php echo e(__('home.h1.2'), false); ?></span>
					<br>
                    <span class="hero__title"><?php echo e(__('home.h1.3'), false); ?></span>
                </h1>

                <span class="hero__elem mob"><?php echo e(__('home.down'), false); ?></span>
                <div class="hero__el dest-f ps-40">
                    <span class="hero__el--arrow"></span>
                    <span class="hero__el--text"><?php echo e(__('home.down'), false); ?></span>
                </div>
            </div>
            <div class="hero__img d-none-f">
                <img class="img-js" src="<?php echo e(Vite::asset('resources/images/png/mask-sudo-tilda.png'), false); ?>" alt="">
                <!-- <img class="img-js" src="images/svg/sudo.svg" alt=""> -->
            </div>
        </section>

        <section class="card-box index-about ps-40">
            <div class="index-about__wrap">
                <div class="index-about__block-one">
                    <h2><?php echo e(__('home.subtitle'), false); ?></h2>
                </div>
                <div class="index-about__block-two">
                    <p>
                        <?php echo e(__('home.text'), false); ?>

                    </p>
                    <a class="btn btn--white elem-a1 wow fadeInUp" href="<?php echo e(route('about'), false); ?>">
                        <span><?php echo e(__('home.more'), false); ?></span>
                        <i class="icon-enter"></i>
                    </a>
                </div>
            </div>
        </section>

		<?php if(slides()->isNotEmpty()): ?>
			<div class="ps-100 container">
				<?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.home-page-slider.index','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('home-page-slider'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
					<?php $__currentLoopData = slides(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.home-page-slider.slide','data' => ['slide' => $slide,'position' => $loop->iteration,'total' => $loop->count]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('home-page-slider.slide'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['slide' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($slide),'position' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($loop->iteration),'total' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($loop->count)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
			</div>
		<?php endif; ?>

        <section class="card-box index-benefits ps-40">
            <div class="index-benefits__block container">
                <div class="index-benefits__block-1">
                    <h3 class="index-benefits__title"><?php echo e(__('home.advantages.title'), false); ?></h3>
                </div>
                <div class="index-benefits__block-2">
                    <div class="wave-block dest">
                        <ul class="wave-block__list">
                            <li class="wave-block__item">
                                <img src="<?php echo e(Vite::asset('resources/images/jpg/wave-left.jpg'), false); ?>" alt="#">
                            </li>
                            <li class="wave-block__item elem-a8">
                                <img src="<?php echo e(Vite::asset('resources/images/jpg/wave-center-1.jpg'), false); ?>" alt="#">
                            </li>
                            <li class="wave-block__item elem-a9">
                                <img src="<?php echo e(Vite::asset('resources/images/jpg/wave-center-2.jpg'), false); ?>" alt="#">
                            </li>
                            <li class="wave-block__item elem-a10">
                                <img src="<?php echo e(Vite::asset('resources/images/jpg/wave-center-3.jpg'), false); ?>" alt="#">
                            </li>
                            <li class="wave-block__item">
                                <img src="<?php echo e(Vite::asset('resources/images/jpg/wave-right.jpg'), false); ?>" alt="#">
                            </li>
                        </ul>
                    </div>
                    <ul class="index-benefits__list">
                        <li class="index-benefits__item wow fadeInUp" data-wow-delay=".5s" data-wow-duration=".5s"><?php echo e(__('home.advantages.1'), false); ?></li>
                        <li class="index-benefits__item wow fadeInUp" data-wow-delay=".5s" data-wow-duration="1s"><?php echo e(__('home.advantages.2'), false); ?></li>
                        <li class="index-benefits__item wow fadeInUp" data-wow-delay=".5s" data-wow-duration="1.5s"><?php echo e(__('home.advantages.3'), false); ?></li>
                    </ul>
                </div>
            </div>
        </section>

        <section class="card-box index-services ps-40">
            <div class="index-services__block container">
                <div class="index-services__block-1">
                    <h3 class="color--white mb-28"><?php echo e(__('home.services.title'), false); ?></h3>
                    <a class="btn btn--white border-color wow fadeInUp" href="<?php echo e(route('services'), false); ?>">
                        <span class="color--white"><?php echo e(__('home.more'), false); ?></span>
                        <i class="icon-enter"></i>
                    </a>
                </div>
                <div class="services-block index-services__block-2">

                    <div class="services-block__nav color--white">
                        <button class="services-block__nav-btn-l color--white border-color" disabled>
                            <i class="icon-arrow color--white"></i>
                        </button>
                        <button class="services-block__nav-btn-r color--white border-color">
                            <i class="icon-arrow color--white"></i>
                        </button>
                    </div>

                    <div class="services-block__progess bg--2931">
                        <span class="services-block__progess--elem bg--white"></span>
                    </div>

                    <ul class="services-block__list">
                        <li class="services-block__item services-block__item--active color--white">
                            <h4 class="color--white wow fadeInUp"><?php echo e(__('home.services.1.title'), false); ?></h4>
                            <p class="color--white wow fadeInUp"><?php echo e(__('home.services.1.text'), false); ?></p>
                        </li>
                        <li class="services-block__item color--white">
                            <h4 class="color--white wow fadeInUp"><?php echo e(__('home.services.2.title'), false); ?></h4>
                            <p class="color--white wow fadeInUp"><?php echo e(__('home.services.2.text'), false); ?></p>
                        </li>
                        <li class="services-block__item color--white">
                            <h4 class="color--white wow fadeInUp"><?php echo e(__('home.services.3.title'), false); ?></h4>
                            <p class="color--white wow fadeInUp"><?php echo e(__('home.services.3.text'), false); ?></p>
                        </li>
                    </ul>
                </div>
            </div>
        </section>

        <section class="card-box index-mission ps-40 mt-40">
            <div class="index-mission__block ret-1 container">
                <div>
                    <div class="index-mission__text-animate">
						<?php
							$lang = app()->getLocale();
						?>
                        <img class="index-mission__text-animate--1 anime-9" 
							src="<?php echo e(Vite::asset("resources/images/svg/text_{$lang}.svg"), false); ?>" alt=""
						/>
                        <a class="index-mission__text-animate--2" href="<?php echo e(route('career'), false); ?>">
                            <img src="<?php echo e(Vite::asset('resources/images/png/play.png'), false); ?>" alt="">
                        </a>
                    </div>
                    <p class="index-mission__text wow fadeInUp">
                        <?php echo e(__('home.career.text'), false); ?>

                    </p>
                </div>
                <div>
                    <div class="d-none-f d-none-996">
                        <img src="<?php echo e(Vite::asset('resources/images/jpg/bg_main-6.jpg'), false); ?>" alt="">
                    </div>
                </div>


            </div>
        </section>
    </main>

    <section class="modal-feedback">
        <button class="modal-feedback__close">
            <i class="icon-close"></i>
        </button>
        <h3 class="modal-feedback__title"><?php echo e(__('request-form.title'), false); ?></h3>
        <p class="modal-feedback__text"><?php echo e(__('request-form.subtitle'), false); ?></p>
        <form class="form">
			<?php echo csrf_field(); ?>
			<input type="hidden" name="to" value="<?php echo e(contacts()->email, false); ?>">
			<input type="hidden" name="subject" value="Заявка с сайта">
            <input class="form__input" name="name" type="text" placeholder="<?php echo e(__('request-form.person'), false); ?>">
            <input class="form__input" name="phone" type="tel" placeholder="<?php echo e(__('request-form.phone'), false); ?>">
            <input class="form__input" name="email" type="email" placeholder="Email" required>
            <textarea class="form__textarea" name="description" placeholder="<?php echo e(__('request-form.description'), false); ?>"></textarea>
            <label class="form__checkbox">
                <input class="form__input--none" type="checkbox" required>
                <span class="form__checkbox-elem"></span>
                <span class="form__checkbox-text text-justify ">
                    <?php echo e(__('request-form.check'), false); ?> <a href="<?php echo e(route('policy'), false); ?>"><?php echo e(__('request-form.policy'), false); ?></a>
                </span>
            </label>
            <button type="submit" class="form__btn btn">
                <span><?php echo e(__('request-form.btn'), false); ?></span>
                <i class="icon-enter"></i>
            </button>
        </form>
    </section>

    <!-- Модальное окно Благодарности -->
    <section class="modal fade thank-modal" id="thankYouModal" aria-labelledby="thankYouModalLabel" aria-hidden="true"
        tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header border-0">
                    <button class="thank-modal__btn-close btn-close" data-bs-dismiss="modal" type="button"
                        aria-label="Закрыть"></button>
                </div>
                <div class="modal-body d-flex justify-content-center align-items-center">
                    <div class="thank-modal__content">
                        <p class="thank-modal__text w-75 h2 m-auto px-4 pb-3 text-center">
                            <?php echo e(__('request-form.tnx'), false); ?>

                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body_scripts'); ?>
	<script src="libs/jquery-3.6.3.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>
    <script src="js/jquery.enllax.min.js"></script>
    <script src="js/wow.min.js"></script>
    <script src="libs/bezier.js"></script>
    <script src="libs/swiped-events.min.js"></script>
    <script src="libs/gsap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.js"></script>
    <!-- <script src="js/animate.js"></script> -->
    <script src="js/a4.js"></script>
    <script src="js/app.js"></script>
    <script>
        new WOW().init();

        $(window).enllax();



        const indexBlockBbtn = document.querySelectorAll('.request-button')
        const modalFeedback = document.querySelector('.modal-feedback')



        indexBlockBbtn.forEach(function (event) {
            event.addEventListener('click', function (event) {
                modalFeedback.classList.add('modal-feedback--active')

                modalFeedback.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                })
            })
        })


        const modalFeedbackClose = document.querySelector('.modal-feedback__close')

        modalFeedbackClose.addEventListener('click', () => {
            modalFeedback.classList.remove('modal-feedback--active')
        })

        const servicesBlockNavBtnLeft = document.querySelector('.services-block__nav-btn-l')
        const servicesBlockNavBtnRight = document.querySelector('.services-block__nav-btn-r')
        const servicesBlockItem = document.querySelectorAll('.services-block__item')
        const servicesBlockProgess = document.querySelector('.services-block__progess--elem')
        let count = 0
        let positionElement = 0

        let i = 100 / servicesBlockItem.length
        servicesBlockProgess.style.width = i + '%'

        servicesBlockNavBtnRight.addEventListener('click', () => {
            count++
            positionElement += i
            servicesBlockNavBtnLeft.removeAttribute('disabled');
            if (count == servicesBlockItem.length - 1) {
                servicesBlockNavBtnRight.setAttribute('disabled', false);
            }
            servicesBlockProgess.style.left = positionElement + "%"
            servicesBlockItem.forEach(el => el.classList.remove('services-block__item--active'))
            servicesBlockItem[count].classList.add('services-block__item--active')
        })

        servicesBlockNavBtnLeft.addEventListener('click', () => {
            count--
            positionElement -= i
            servicesBlockNavBtnRight.removeAttribute('disabled');
            if (count == 0) {
                servicesBlockNavBtnLeft.setAttribute('disabled', true);
            }
            servicesBlockProgess.style.left = positionElement + "%"
            servicesBlockItem.forEach(el => el.classList.remove('services-block__item--active'))
            servicesBlockItem[count].classList.add('services-block__item--active')
        })


        const swiper = new Swiper('.swiper-box', {
            slidesPerView: 1,
            spaceBetween: 20,
            loop: true,
            navigation: {
                nextEl: ".swiper-button-next",
                prevEl: ".swiper-button-prev",
            },
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/aner/web_dev/sudo/resources/views/home.blade.php ENDPATH**/ ?>