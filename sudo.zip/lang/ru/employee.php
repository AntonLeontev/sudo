<?php

return [
    'Add to contacts' => 'Добавить в контакты',
    'Contact' => 'Контакт',
    'Company' => 'Компания',
    'Socials' => 'Соц сети',
    'Mobile phone' => 'Мобильный',
    'Email' => 'Email',
    'Personal website' => 'Сайт',
    'Location' => 'Адрес',
    'Profession' => 'Должность',
    'Phone' => 'Телефон',
    'to the website' => 'Перейти на сайт',
];
