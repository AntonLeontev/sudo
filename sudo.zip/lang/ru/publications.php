<?php

return [
    'title' => 'Публикации',
    'h1' => 'Публикации',
    'publication' => [
        'button' => 'Узнать больше',
    ],
];
