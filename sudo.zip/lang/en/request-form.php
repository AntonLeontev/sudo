<?php

return [
    'title' => 'Do you want to offer cooperation or order a service?',
    'subtitle' => 'Fill out the form and our specialists will contact you to discuss the details.',
    'person' => 'Name',
    'phone' => 'Phone',
    'description' => 'Brief description of the project',
    'check' => 'By clicking the Send button, I consent to the processing of my personal data and agree to the',
    'policy' => 'Privacy Policy',
    'btn' => 'Send',
    'tnx' => 'Thanks! Your request was accepted',
];
